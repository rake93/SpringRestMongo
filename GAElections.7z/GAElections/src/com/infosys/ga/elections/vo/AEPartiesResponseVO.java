package com.infosys.ga.elections.vo;

public class AEPartiesResponseVO {

	private String party1;
	private int count;

	public String getParty1() {
		return party1;
	}

	public void setParty1(String party1) {
		this.party1 = party1;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

}
